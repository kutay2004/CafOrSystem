CafOrSystem - Kafe Yönetim Sistemi
Bu proje, bir kafenin ürün, kategori, çalışan ve müşteri yönetimini dijitalleştirmek amacıyla geliştirilmiş modern bir Blazor Web App uygulamasıdır.

Özellikler
Ürün Yönetimi: Kafe menüsündeki ürünlerin eklenmesi, güncellenmesi ve silinmesi.

Kategori Sistemi: Ürünlerin gruplandırılması ve ilişkisel veri takibi.

Görsel Ana Sayfa: Kullanıcıyı karşılayan pasta ve kahve temalı dinamik içerik.

İlişkisel Veritabanı: Tablolar arası Foreign Key ve .Include() metotları ile veri yönetimi.

 Kullanılan Teknolojiler
Framework: .NET 8 / Blazor Web App.

ORM: Entity Framework Core (Database-First).

Veritabanı: Microsoft SQL Server.

 Kurulum ve Çalıştırma
1. Veritabanı Yapılandırması
SQL Server üzerinde CafOrSystem adında bir veritabanı oluşturun.

ZIP dosyasında bulunan Caforsql.sql dosyasını SSMS ile açıp bu veritabanında çalıştırarak tabloları ve verileri oluşturun.

2. Bağlantı Ayarları
appsettings.json dosyasındaki bağlantı dizesi şu şekilde yapılandırılmıştır:

JSON

"ConnectionStrings": {
  "CafOrSystemWebContext": "Server=DESKTOP-PQ9II1K\\SQLEXPRESS;Database=CafOrSystem;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True;"
}
3. Projeyi Çalıştırma
Visual Studio'da .sln dosyasını açın.

Build > Rebuild Solution adımlarını izleyin.

F5 tuşuna basarak uygulamayı başlatın.

Sunum İçin Önemli Notlar (Sorularına Göre Güncellendi):
Data Connectivity: Veritabanına bağlantı, yukarıdaki bağlantı dizesi ile sağlanmıştır. DESKTOP-PQ9II1K\SQLEXPRESS sunucusundaki CafOrSystem veritabanı hedef alınmıştır.

Challenges: En büyük zorluk, veritabanı ismi ve bağlantı dizesi hiyerarşisinin (ConnectionStrings bloğu) doğru yapılandırılmasıydı; bu sorun JSON formatı standartlarına göre çözülmüştür.

SQL Script: Teslim edilen Caforsql.sql dosyası, hem tablo yapılarını (schema) hem de içerisindeki pasta/kahve verilerini barındırmaktadır.