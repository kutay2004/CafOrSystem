﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DataAccess;

namespace SengWeb.Data
{
    public class SengWebContext : DbContext
    {
        public SengWebContext (DbContextOptions<SengWebContext> options)
            : base(options)
        {
        }

        public DbSet<DataAccess.Course> Course { get; set; } = default!;

        public DbSet<DataAccess.Curriculum> Curriculum { get; set; } = default!;

    }
}
